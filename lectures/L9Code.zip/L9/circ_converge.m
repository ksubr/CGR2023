

c = [0.5 0.5] ;
r = 1/10 ;

clf
viscircles(c,r, 'Color', 'blue') ;
axis([0,1,0,1]) ;
hold on; 

Ns = 500:300:25000 ;
rep  = 1000 ;

tic 
clear errPi ;
for i=1:length(Ns)
    clear piEst;
    for j = 1:rep
        N = Ns(i) ;
        S = rand(N,2) ;
        Sx = S(:,1) ;
        Sy = S(:,2) ;
%         scatter(Sx, Sy, 'xr') ;
        
        d = vecnorm((S-c)') ;
        inside = find(d<=r) ;
        n = length(inside) ;
%         scatter(Sx(inside), Sy(inside), '+k') ;
        
        refA = pi*r^2 ;
        estA = n/N ;
        
        piEst(j) = estA/r^2 ;
    end
    meanPi = mean(piEst) ;
    errPi(i) = (meanPi - pi) ;
    varPi(i) = var(piEst) ;
end
toc

hold off;
disp('done') ;

figure(2)
loglog (Ns, abs(errPi))
hold on
loglog (Ns, varPi, 'r')

loglog (Ns, 2e-1./sqrt(Ns), '--k')
loglog (Ns, 100./Ns, '-.k')
hold off

legend({'Error', 'Var', '1/N', '1/sqrt(N)'}, 'fontsize', 20, 'box', 'off')
