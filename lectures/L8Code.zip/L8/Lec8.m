% Define a function
f = @(x) x.^2;
f = @(x) x.^5;
f = @(x) sin(exp(-x).*x.^2);


% Reference integral in [0,1]
refInt = integral(f, 0,1) ;
display(['The reference integral is ' num2str(refInt)]);

Ns = [2, 5,  10, 100, 500, 1000, 5000, 10000];
clear err;
for i = 1:length(Ns)
    N = Ns(i) ;
    % Evaluate the function at N points
    x = linspace(0,1,N) ;
    y = f(x) ;
    
    % plot function
    %     MyPlot(x,y,f)
    
    % intuitive estimate of integral
    avg = mean(y) ;
    display(['The average of ' num2str(N) ' values is ' num2str(avg)]);
    
    % area using rectangles
    w = x(2)-x(1) ;
    xcentres = x+w/2; 
    xcentres(end)=[];
    recInt = sum(w*f(xcentres)) ;
    display(['The sum of ' num2str(N) ' rectangles is ' num2str(recInt)]);
    
    % plot function
    %     MyBoxPlot(x,y,f);
    
    % area using rectangles
    % w*(a+b)/2
    xstart = x;
    xstart(end)=[];
    xend = xstart+w ;
    aplusb = f(xstart) + f(xend) ;
    trapArea = w*aplusb/2 ;
    trapInt = sum(trapArea);
    display(['The sum of ' num2str(N) ' traps. is ' num2str(trapInt)]);
    
    % plot function
    %     MyTrapPlot(x,y,f);
    
    MSE = [avg-refInt, recInt-refInt, trapInt-refInt].^2 ;
    
   err(i,:) = MSE; 
end


clf; 
hold on
for k=1:size(err,2)
    plot(Ns, err(:,k), 'o-' );
end
set(gca, 'xscale', 'log') ;
set(gca, 'yscale', 'log') ;
hold off
legend({'avg', 'rec', 'trap'});



































